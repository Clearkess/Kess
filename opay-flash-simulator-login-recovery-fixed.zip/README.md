# Flash Transfer Simulator

A real-user wallet application with **simulated money only**. Nigerian bank/account-name verification uses Paystack's Resolve Account API, but the project never calls Paystack's transfer endpoint.

## Backend
1. `cd backend`
2. `npm install`
3. Copy `.env.example` to `.env`
4. Add `JWT_SECRET` and your backend-only `PAYSTACK_SECRET_KEY`.
5. `npm start`

API runs on `http://localhost:3000` by default.

## Frontend
Serve the `frontend` directory from a local static server and open `transfer.html`. Set `localStorage.SIM_API` if the API is hosted elsewhere.

## Important
- Balances are internal simulated balances.
- Account verification is real provider-backed verification.
- No real bank transfer is performed.
- Never put `PAYSTACK_SECRET_KEY` in frontend code.
- Before production use, add stronger rate limits, CSRF/origin controls, structured logging, secrets management, and comprehensive automated tests.

## Vercel deployment

This version is prepared for Vercel Functions + a PostgreSQL database. Do not use local SQLite in production because Vercel function storage is not durable.

1. Create a PostgreSQL database (for example through Vercel Marketplace/Neon/Supabase).
2. Import this repository into Vercel.
3. Add these Production environment variables: `DATABASE_URL`, `JWT_SECRET`, `PAYSTACK_SECRET_KEY`, `FRONTEND_URL`, `NODE_ENV=production`.
4. Deploy.
5. Open `/api/health` and confirm `database: "connected"`.
6. Register a test user, add simulated funds, verify an account, and make a simulated transfer.

### Important
- Paystack is used only for Nigerian bank-list/account-name verification.
- This application does not call Paystack's transfer endpoint.
- No real money is moved.
- The simulated funding endpoint is for testing only and must not be presented as a real deposit method.
- Vercel serverless deployment uses REST polling for notifications; Socket.IO/WebSockets are not required for the production path.
