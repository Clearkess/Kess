# Deploying to Vercel

Architecture: `frontend/` is served statically, and every `/api/*` request is routed
to a single Express app exported from `api/index.js` as a Vercel Node function.
State lives in PostgreSQL — Vercel's filesystem is ephemeral, so local SQLite is not usable.

## 1. Create the database

Any managed Postgres works (Vercel Marketplace → Neon, Supabase, or an existing instance).
Copy the connection string; it becomes `DATABASE_URL`. Keep `?sslmode=require`.

## 2. Set environment variables (Production **and** Preview)

| Variable | Required | Notes |
|---|---|---|
| `DATABASE_URL` | yes | Postgres connection string |
| `JWT_SECRET` | yes | long random string, e.g. `openssl rand -hex 32`; required to issue login tokens |
| `SIMULATOR_RESET_TOKEN` | optional, recommended for test-account recovery | Generate a separate random value of at least 32 characters; keep it private and enter it only on the recovery page |
| `PAYSTACK_SECRET_KEY` | yes | backend only — never in frontend code |
| `FRONTEND_URL` | strongly recommended | CORS allow-list; comma-separate multiple origins |
| `NODE_ENV` | yes | `production` |
| `SIM_DAILY_FUNDING_CAP` | optional | default `1000000` (₦1,000,000 / 24h) |

CLI form:

```sh
vercel env add DATABASE_URL production
vercel env add JWT_SECRET production
vercel env add SIMULATOR_RESET_TOKEN production
vercel env add PAYSTACK_SECRET_KEY production
vercel env add FRONTEND_URL production
vercel env add NODE_ENV production
```

## 3. Deploy

```sh
npx vercel@latest --prod
```

Or push to a Git repository and import it at vercel.com/new.

Tables are created automatically on the first request (`initDb` is idempotent),
so no migration step is needed.

## 4. Verify

```sh
curl -s https://<your-deployment>/api/health | jq
```

Expect `database: "connected"` and all three `config` flags `true`. If the database
is unreachable you get HTTP 503 with `database: "unavailable"` — **not** a 500 crash.

Then walk the happy path: register → add simulated funds → verify an account → send.

## Notes on the config

`vercel.json` uses the legacy `builds` + `routes` form, which forwards `/api/(.*)` to
`api/index.js` while preserving the original request path (so Express sees `/api/auth/login`).
If you migrate to modern `rewrites`, the equivalent is:

```json
{
  "version": 2,
  "outputDirectory": "frontend",
  "rewrites": [{ "source": "/api/(.*)", "destination": "/api/index" }]
}
```

Verify `/api/health` after switching, because rewrite semantics differ from `dest` routing.

## Operational caveats

- **Idempotency**: send an `Idempotency-Key` header on `POST /api/transfers/simulated`
  to make retries safe. The bundled frontend already does this.
- **Rate limiting** is DB-backed (`auth_attempts` table) because serverless instances
  do not share memory. It fails open if the database is unreachable.
- **This is a simulator.** Balances are internal integers in kobo; no Paystack transfer
  endpoint is ever called. `fund-simulated` is a test helper, not a deposit method.


## Test-account password recovery

The `login.html` page links to `reset-password.html`. Recovery is disabled until the site owner configures `SIMULATOR_RESET_TOKEN` in Vercel Production (and Preview if needed). Generate a separate random secret, at least 32 characters long, and add it as a server environment variable. Do not put it in frontend code or share it publicly. Redeploy after setting environment variables. On the recovery page, enter the registered email, a new password of at least 8 characters, and the private recovery token. This is an owner-authorized test-account recovery mechanism, not an email-based password reset system.

Also set `JWT_SECRET` to a separate strong random secret. Without it, password verification may succeed but token issuance fails. Check `/api/health` after redeploy; `database` should be `connected`, and `config.jwt_secret` should be `true`.
