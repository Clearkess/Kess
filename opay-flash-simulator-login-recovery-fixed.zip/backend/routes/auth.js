const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { getPool, initDb } = require('../db');
const limiter = require('../middleware/throttle');

const r = express.Router();

function token(u) {
  return jwt.sign({ id: String(u.id), email: u.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
}

const loginLimit = limiter({
  limit: 10,
  windowMs: 15 * 60 * 1000,
  key: (req) => `login:${String((req.body && req.body.email) || '').toLowerCase().trim()}`
});
const registerLimit = limiter({
  limit: 20,
  windowMs: 60 * 60 * 1000,
  key: (req) => `register:${req.ip}`
});

r.post('/register', registerLimit, async (req, res, next) => {
  try {
    await initDb();
    const { name, email, phone, password } = req.body || {};
    if (!name || !email || !password || password.length < 6) {
      return res.status(400).json({ success: false, error: 'Name, email and password (6+ characters) are required' });
    }
    const client = await getPool().connect();
    try {
      await client.query('BEGIN');
      const hash = await bcrypt.hash(password, 10);
      const { rows } = await client.query(
        'INSERT INTO users(name,email,phone,password_hash) VALUES($1,$2,$3,$4) RETURNING id,name,email,phone',
        [String(name).trim().slice(0, 120), String(email).toLowerCase().trim(), phone || null, hash]
      );
      await client.query('INSERT INTO wallets(user_id,balance) VALUES($1,0)', [rows[0].id]);
      await client.query('COMMIT');
      return res.json({ success: true, user: rows[0], token: token(rows[0]) });
    } catch (e) {
      await client.query('ROLLBACK');
      if (e.code === '23505') return res.status(409).json({ success: false, error: 'Email or phone already exists' });
      throw e;
    } finally {
      client.release();
    }
  } catch (e) {
    next(e);
  }
});

r.post('/login', loginLimit, async (req, res, next) => {
  try {
    await initDb();
    const { rows } = await getPool().query('SELECT * FROM users WHERE email=$1', [
      String((req.body && req.body.email) || '').toLowerCase().trim()
    ]);
    const u = rows[0];
    const ok = u && (await bcrypt.compare(String((req.body && req.body.password) || ''), u.password_hash));
    if (!ok) return res.status(401).json({ success: false, error: 'Invalid email or password' });
    return res.json({ success: true, user: { id: u.id, name: u.name, email: u.email, phone: u.phone }, token: token(u) });
  } catch (e) {
    next(e);
  }
});


// Owner-controlled recovery for test accounts. This endpoint is disabled unless
// SIMULATOR_RESET_TOKEN is configured on the server; the token is never stored
// in or shipped with the frontend. Do not use this as a production email-reset flow.
r.post('/reset-test-password', async (req, res, next) => {
  try {
    const configuredToken = process.env.SIMULATOR_RESET_TOKEN || '';
    const suppliedToken = String(req.get('x-simulator-reset-token') || '');
    if (configuredToken.length < 32) {
      return res.status(503).json({ success: false, error: 'Test-account recovery is not configured by the site owner' });
    }
    const a = Buffer.from(configuredToken);
    const b = Buffer.from(suppliedToken);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(403).json({ success: false, error: 'Recovery authorization failed' });
    }

    const email = String((req.body && req.body.email) || '').toLowerCase().trim();
    const password = String((req.body && req.body.password) || '');
    if (!email || !email.includes('@') || password.length < 8) {
      return res.status(400).json({ success: false, error: 'Enter a valid email and a new password of at least 8 characters' });
    }

    await initDb();
    const hash = await bcrypt.hash(password, 10);
    const result = await getPool().query(
      'UPDATE users SET password_hash=$1 WHERE email=$2 RETURNING id',
      [hash, email]
    );
    if (!result.rowCount) {
      return res.status(404).json({ success: false, error: 'No test account was found for that email' });
    }
    return res.json({ success: true, message: 'Test-account password updated. You can now log in.' });
  } catch (e) {
    next(e);
  }
});

module.exports = r;
