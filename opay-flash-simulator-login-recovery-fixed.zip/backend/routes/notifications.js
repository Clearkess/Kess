const express = require('express');
const { pool, initDb } = require('../db');
const auth = require('../middleware/auth');
const r = express.Router();
r.get('/', auth, async (req,res) => { await initDb(); const {rows}=await pool.query(`SELECT id,title,body,read,created_at AS "createdAt" FROM notifications WHERE user_id=$1 ORDER BY id DESC LIMIT 50`,[req.user.id]); res.json({success:true,notifications:rows}); });
r.post('/:id/read', auth, async (req,res) => { await initDb(); await pool.query('UPDATE notifications SET read=TRUE WHERE id=$1 AND user_id=$2',[req.params.id,req.user.id]); res.json({success:true}); });
module.exports=r;
