const jwt=require('jsonwebtoken');
module.exports=(req,res,next)=>{const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):null;if(!token)return res.status(401).json({success:false,error:'Authentication required'});try{req.user=jwt.verify(token,process.env.JWT_SECRET)}catch(e){return res.status(401).json({success:false,error:'Invalid or expired session'})}next()};
