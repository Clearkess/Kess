require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { initDb } = require('./db');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1); // Vercel terminates TLS in front of the function

// CORS: explicit allow-list. An unset FRONTEND_URL must NOT fall back to
// reflecting every origin (the previous `|| true` did exactly that).
const allowlist = (process.env.FRONTEND_URL || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

app.use(
  cors({
    origin(origin, cb) {
      if (!origin) return cb(null, true); // non-browser clients are unaffected by CORS
      if (!allowlist.length) return cb(null, false); // secure default: same-origin only
      return cb(null, allowlist.includes(origin));
    },
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Idempotency-Key']
  })
);
app.use(express.json({ limit: '100kb' }));

app.get('/api/health', async (_req, res) => {
  const config = {
    database_url: Boolean(process.env.DATABASE_URL),
    jwt_secret: Boolean(process.env.JWT_SECRET),
    test_account_recovery: Boolean(process.env.SIMULATOR_RESET_TOKEN && process.env.SIMULATOR_RESET_TOKEN.length >= 32),
    paystack_key: Boolean(process.env.PAYSTACK_SECRET_KEY)
  };
  try {
    await initDb();
    return res.json({ success: true, simulated: true, database: 'connected', config });
  } catch (e) {
    console.error('[health]', e.message);
    return res.status(503).json({
      success: false,
      simulated: true,
      database: 'unavailable',
      config,
      error: 'Database unavailable'
    });
  }
});

app.get('/api/version', (_req, res) =>
  res.json({ success: true, name: 'opay-flash-simulator', version: '2.1.0', simulated: true })
);

app.use('/api/auth', require('./routes/auth'));
app.use('/api/banks', require('./routes/banks'));
app.use('/api/wallet', require('./routes/wallet'));
app.use('/api/transfers', require('./routes/transfers'));
app.use('/api/notifications', require('./routes/notifications'));

// Unknown /api/* paths must return JSON 404, not fall through to the static handler.
app.use('/api', (_req, res) => res.status(404).json({ success: false, error: 'Not found' }));

app.use((err, _req, res, _next) => {
  console.error('[error]', err);
  if (res.headersSent) return;
  res.status(err.status || 500).json({
    success: false,
    error: err.status ? err.message : 'Internal server error'
  });
});

module.exports = app;
